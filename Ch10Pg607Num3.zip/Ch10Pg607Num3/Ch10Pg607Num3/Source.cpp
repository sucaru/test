#include <string>
#include <cctype>
#include <iomanip>
#include <iostream>

using namespace std;

int wordCount(char*);

int main()
{
	char sentence[281];
	cout << "Enter a string (Twitter max character limit is 280 characters) : ";
	cin.getline(sentence, 281);
	cout << "'" << sentence << "' has " << wordCount(sentence) << " words" << endl;
	system("pause");
	return 0;




}

int wordCount(char* sentence)

{
	int i = 0;
	int count = 1;
	for (i = 0; *(sentence + i) != '\0'; i++) {
		if (*(sentence + i) == ' ') {
			count++;
		}
	}
	return count;

}